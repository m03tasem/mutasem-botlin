# Viprofix
BOT PROTECT CREATOR & ADMIN
------
GET TOKEN :
------
- `Google Chrome`
- `http://101.255.95.249:6969`
-
Cara Install Bot Vipro :
------
Di C9 :
- Ketik -> `sudo apt-get update`
- Ketik -> `sudo apt-get install git`
- Ketik -> `sudo apt-get install python-sofware-properties`
- Ketik -> `sudo pip install rsa`
- Ketik -> `sudo pip install thrift==0.9.3`
- Ketik -> `sudo pip install requests`
- Ketik -> `sudo pip install requests==2.5.3`
- Ketik -> `sudo pip install bs4`
- Ketik -> `sudo pip install gtts`
- Ketik -> `sudo pip install googletrans`
- Ketik -> `git clone https://github.com/Gendjex/vipro2`
- Ketik -> `cd vipro2`
- Ketik -> `python vipro.py`

Di Termux :
- Ketik -> `pkg update`
- Ketik -> `pkg install git`
- Ketik -> `pkg install python2`
- Ketik -> `pip2 install rsa`
- Ketik -> `pip2 install thrift==0.9.3`
- Ketik -> `pip2 install requests`
- Ketik -> `pip2 install bs4`
- Ketik -> `pip2 install gtts`
- Ketik -> `pip2 install beautifulsoup`
- Ketik -> `pip2 install googletrans`
- Ketik -> `git clone https://github.com/Gendjex/vipro2`
- Ketik -> `cd vipro2`
- Ketik -> `python2 vipro.py`

Cara Menjalankan Bot Kembali :
------
Di C9 :
- Ketik -> `cd vipro2`
- Ketik -> `python vipro.py`

Di Termux :
- Ketik -> `cd vipro2`
- Ketik -> `python2 vipro.py`


Credit By@ Vipro.
------
- `Add My ID LINE : gjxvipro`

Thx To :
------
- `LINE-TCR TEAM`

